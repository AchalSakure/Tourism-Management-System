create Database tourism;
use tourism;


CREATE TABLE `bookfood` (
  `type` varchar(45) NOT NULL,
  `foodName` varchar(45) NOT NULL,
  `foodCost` varchar(45) NOT NULL,
  `quantity` varchar(45) NOT NULL,
  `totalCost` int(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `packagename` varchar(45) NOT NULL,
  `place` varchar(45) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


INSERT INTO `bookfood` (`type`, `foodName`, `foodCost`, `quantity`, `totalCost`, `email`, `packagename`, `place`) VALUES
('Non-Veg', 'Butter Chicken', '15', '3', 45, 'luffy', 'green building', 'missori'),
('Non-Veg', 'Chicken Biryani', '10', '1', 10, 'luffy', 'green building', 'missori');


CREATE TABLE `bookpackage` (
  `id` int(3) NOT NULL,
  `packagename` varchar(45) NOT NULL,
  `place` varchar(45) NOT NULL,
  `packageCost` varchar(45) NOT NULL,
  `days` varchar(45) NOT NULL,
  `noofPersons` varchar(45) NOT NULL,
  `totalcost` int(45) NOT NULL,
  `email` varchar(45) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


INSERT INTO `bookpackage` (`id`, `packagename`, `place`, `packageCost`, `days`, `noofPersons`, `totalcost`, `email`) VALUES
(1, 'green building', 'washington', '30', '1', '1', 30, 'nikesh@gmail.com'),
(2, 'Snow Time', 'NC', '20', '2', '1', 20, 'nikesh@gmail.com'),
(1, 'waterfall', 'nc', '20', '1', '1', 20, 'sai@gmail.com'),
(2, 'Snow Time', 'NC', '20', '2', '1', 20, 'sai@gmail.com'),
(1, 'Snow Time', 'NC', '20', '2', '10', 200, 'nikesh2804@gmail.com'),
(3, 'green building', 'missori', '30', '2', '1', 30, 'nikesh@gmail.com'),
(1, 'green building', 'missori', '30', '2', '2', 60, 'luffy');


CREATE TABLE `bookroom` (
  `hotelName` varchar(45) NOT NULL,
  `roomType` varchar(45) NOT NULL,
  `roomSize` varchar(45) NOT NULL,
  `roomCost` int(45) NOT NULL,
  `roomDate` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `packagename` varchar(45) NOT NULL,
  `place` varchar(45) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



INSERT INTO `bookroom` (`hotelName`, `roomType`, `roomSize`, `roomCost`, `roomDate`, `email`, `packagename`, `place`) VALUES
('swagath', 'AC', 'Single', 100, '2017-02-23', 'luffy', 'green building', 'missori'),
('Taj', 'AC', 'Double', 300, '2017-02-15', 'nikesh2804@gmail.com', 'Snow Time', 'NC'),
('Taj', 'AC', 'Double', 300, '2017-02-16', 'nikesh2804@gmail.com', 'Snow Time', 'NC');


CREATE TABLE `booktransport` (
  `transportType` varchar(45) NOT NULL,
  `vehicleType` varchar(45) NOT NULL,
  `vehicleName` varchar(45) NOT NULL,
  `vehicleCost` int(45) NOT NULL,
  `vehicleDate` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `packagename` varchar(45) NOT NULL,
  `place` varchar(45) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



INSERT INTO `booktransport` (`transportType`, `vehicleType`, `vehicleName`, `vehicleCost`, `vehicleDate`, `email`, `packagename`, `place`) VALUES
('Car', 'AC', 'sonata sport', 300, '2017-02-17', 'nikesh2804@gmail.com', 'Snow Time', 'NC'),
('Car', 'AC', 'sonata sport', 300, '2017-02-22', 'luffy', 'green building', 'missori');


CREATE TABLE `discount` (
  `packagename` varchar(45) NOT NULL,
  `discount` varchar(45) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



INSERT INTO `discount` (`packagename`, `discount`) VALUES
('green building', '20'),
('waterfall', '10');



CREATE TABLE `food` (
  `foodtype` varchar(45) NOT NULL,
  `foodname` varchar(45) NOT NULL,
  `foodcost` varchar(45) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


INSERT INTO `food` (`foodtype`, `foodname`, `foodcost`) VALUES
('Non-Veg', 'Chicken Biryani', '10'),
('Non-Veg', 'Butter Chicken', '15'),
('Veg', 'Gobi', '5');



CREATE TABLE `hotel` (
  `hotelName` varchar(45) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


INSERT INTO `hotel` (`hotelName`) VALUES
('swagath'),
('taj krishna');



CREATE TABLE `package` (
  `id` int(4) NOT NULL,
  `packagename` varchar(45) NOT NULL,
  `place` varchar(45) NOT NULL,
  `cost` varchar(45) NOT NULL,
  `days` varchar(45) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



INSERT INTO `package` (`id`, `packagename`, `place`, `cost`, `days`) VALUES
(4, 'Snow Time', 'NC', '20', '2'),
(5, 'waterfall', 'nc', '20', '1'),
(7, 'green building', 'washington', '30', '1'),
(8, 'green building', 'missori', '30', '2');



CREATE TABLE `payment` (
  `packagename` varchar(45) NOT NULL,
  `place` varchar(45) NOT NULL,
  `cost` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `cardName` varchar(45) NOT NULL,
  `cardNumber` varchar(45) NOT NULL,
  `cvv` varchar(45) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



INSERT INTO `payment` (`packagename`, `place`, `cost`, `email`, `cardName`, `cardNumber`, `cvv`) VALUES
('green building', 'washington', '27', 'nikesh@gmail.com', 'nikesh', '1234567891523654', '456');



CREATE TABLE `register` (
  `name` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `mobile` varchar(45) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


INSERT INTO `register` (`name`, `email`, `password`, `mobile`) VALUES
('nikesh', 'nikesh@gmail.com', 'sai', '1234567890'),
('sai', 'sai@gmail.com', 'sai', '7894561230'),
('nikesh', 'nikesh2804@gmail.com', '8121343348', '8121343348'),
('luffy', 'luffy', 'luffy', '8794561230');



CREATE TABLE `room` (
  `hotelName` varchar(45) NOT NULL,
  `roomType` varchar(45) NOT NULL,
  `roomSize` varchar(45) NOT NULL,
  `roomCost` varchar(45) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;



INSERT INTO `room` (`hotelName`, `roomType`, `roomSize`, `roomCost`) VALUES
('swagath', 'AC', 'Single', '100'),
('swagath', 'AC', 'Double', '1000'),
('taj krishna', 'Non-AC', 'Single', '15'),
('taj krishna', 'AC', 'Double', '500');


CREATE TABLE `transport` (
  `transportType` varchar(45) NOT NULL,
  `vehicleType` varchar(45) NOT NULL,
  `vehicleName` varchar(45) NOT NULL,
  `vehicleCost` varchar(45) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


INSERT INTO `transport` (`transportType`, `vehicleType`, `vehicleName`, `vehicleCost`) VALUES
('Car', 'AC', 'sonata sport', '300'),
('Bus', 'AC', 'Bus', '50'),
('Mini-Bus', 'Non-AC', 'Mini-Bus', '50'),
('Bus', 'Non-AC', 'Bus', '30'),
('Mini-Bus', 'AC', 'Mini-Bus', '53');


ALTER TABLE `bookpackage`
  ADD KEY `id` (`id`) USING BTREE;

ALTER TABLE `package`
  ADD KEY `id` (`id`);

drop database tourism;

select * from bookfood;
select * from bookpackage;
select * from bookroom;
select * from booktransport;
select * from discount;
select * from food;
select * from hotel;
select * from package;
select * from payment;
select * from register;
select * from room;
select * from transport;
  