package connection;

public interface Provider {
	String CONNECTION_URL="jdbc:mysql://localhost:3306/tourism";
	String USERNAME="root";
	String PASSWORD="Achal@123";
}
